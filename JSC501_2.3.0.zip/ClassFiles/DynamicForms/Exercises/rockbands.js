var rockBands = {
	"beatles" : [
		{
			"name" : "Paul McCartney",
			"value" : "http://www.paulmccartney.com"
		},
		{
			"name" : "John Lennon",
			"value" : "http://www.johnlennon.it"
			
		},
		{
			"name" : "George Harrison",
			"value" : "http://www.georgeharrison.com"
		},
		{
			"name" : "Ringo Starr",
			"value" : "http://www.ringostarr.com"
		}
	],
	"stones" : [
		{
			"name" : "Mick Jagger",
			"value" : "http://www.mickjagger.com"
		},
		{
			"name" : "Keith Richards",
			"value" : "http://www.keithrichards.com"
		},
		{
			"name" : "Charlie Watts",
			"value" : "http://www.rosebudus.com/watts"
		},
		{
			"name" : "Bill Wyman",
			"value" : "http://www.billwyman.com"
		}
	],
	"genesis" : [
		{
			"name" : "Phil Collins",
			"value" : "http://www.philcollins.co.uk"
		},
		{
			"name" : "Peter Gabriel",
			"value" : "http://www.petergabriel.com"
			
		},
		{
			"name" : "Mike Rutherford",
			"value" : "http://www.mike-and-the-mechanics.co.uk"
		}
	],
	"eagles" : [
		{
			"name" : "Don Henley",
			"value" : "http://www.donhenley.com"
		},
		{
			"name" : "Joe Walsh",
			"value" : "http://www.joewalsh.com"
			
		},
		{
			"name" : "Glenn Frey",
			"value" : "http://www.imdb.com/name/nm0004940"
		}
	]
};
